# SpringBoot-Angular4
Learning purpose Technology are Used : Spring Boot, Angular 4, Hibernate, JPA, Mysql   

Totally Two Project
1. UI
2. WebService
