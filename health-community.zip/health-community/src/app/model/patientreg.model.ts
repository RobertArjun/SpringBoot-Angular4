export class PatientRegistration {
    public pname: string;
    public age: any;
    public diseas: string;
    public address: string;
    public phoneNumber: string;
    public dname: string;

    }
